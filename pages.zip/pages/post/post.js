// pages/post.js
Page({

  /**
   * 页面的初始数据
   */
  data: {
    topicShow:false, 
    topicName:0,
    linkShow:false,//链接弹出框
    linkContent:false,//链接主体
    linkSrc: '',//输入的链接
    imagesUpload:false,//上传图片
    voiceShow:false,//音频
    recordingTime: 0,//录音计时
    setInter: "",//录音
    voiceTime:'0:00',
    allList: [//nav
      { 'name': '精华内容', 'id': 1 },
      { 'name': '晒出圣诞气氛', 'id': 2 },
      { 'name': '梦享商户', 'id': 3 },
      { 'name': '狼人杀组局热线', 'id': 4 },
      { 'name': '约个热线', 'id': 5 },
      { 'name': '牵狗绳和猫砂铲使用心得', 'id': 6 },
      { 'name': '健身狂魔', 'id': 7 },
      { 'name': '精致生活大爆炸', 'id': 8 }
    ],
    locationText:'开启定位',
    imagesList:[],//图片上传
    emojisList: new Array(100),//创建表情包
    emojisShow:false,//表情显示
    editorShow:false,//编辑器可编辑状态
    editorBlueGet:false,
    content: '',
  },
  // 自定义事件
  topicS:function(){
    this.setData({
      topicShow: true, 
    })
  },
  topicH:function(){
    this.setData({
      topicShow: false,
    })
  },
  // 录音
  voiceC:function(){
    if (this.data.voiceShow==false){
      this.setData({
        voiceShow:true
      })
    }else{
      this.setData({
        voiceShow: false
      })
    }
  },
  //录音计时器
  recordingTimer: function () {
    let that = this;
    //将计时器赋值给setInter
    that.data.setInter = setInterval(()=>{
        let time = that.data.recordingTime + 1;
        console.log(time)
        that.setData({
          recordingTime: time
        })
      }, 1000);
  },
  //录音事件
  voiceStart(){
    let me=this;
    const recorderManager = wx.getRecorderManager()
    const options = {
      duration: 10000,
      sampleRate: 44100,
      numberOfChannels: 1,
      encodeBitRate: 192000,
      format: 'aac',
      frameSize: 50
    }
    //开始录音计时   
    me.recordingTimer();
    recorderManager.start(options)
    recorderManager.onStart(() => {
      console.log('开始录音')
    }) 
    //错误回调
    recorderManager.onError((res) => {
      console.log(res);
    })  
  },
  // voiceOnPause(){
  //   recorderManager.onPause(() => {
  //     console.log('recorder pause')
  //   })
  // },
  // voiceOnStop(){
  //   recorderManager.onStop((res) => {
  //     console.log('recorder stop', res)
  //     const { tempFilePath } = res
  //   })
  // },
  // voiceOnFrameRecorded(){
  //   recorderManager.onFrameRecorded((res) => {
  //     const { frameBuffer } = res
  //     console.log('frameBuffer.byteLength', frameBuffer.byteLength)
  //   })
  // },
  //编辑框
  emojisC:function(){
    if (this.data.emojisShow==false){
      this.setData({
        emojisShow: true,
        editorShow: true,
      })
    }else{
      this.setData({
        emojisShow: false,
        editorShow: false,
      })
    }
  },
  // 获取焦点
  emojisH(e){
    let that=this;
    this.setData({
      emojisShow: false,
      editorShow:false,
      editorBlueGet:true,
    })
  },
  // 失去焦点
  editorBlur(){
    this.setData({
      editorBlueGet: false
    })
  },
  topicControl(){

  },
  //链接框控制
  linkC(){
    if(this.data.linkShow==true){
      this.setData({
        linkShow:false
      })
    }else{
      this.setData({
        linkShow: true
      })
    }
  },
  bindLinkName(e){
    console.log(e.detail.value)
    this.setData({
      linkSrc: e.detail.value
    })
  },
  //确定添加链接
  commitLink(){
    if (this.data.linkSrc != '') {
      let reg = /^([hH][tT]{2}[pP]:\/\/|[hH][tT]{2}[pP][sS]:\/\/)(([A-Za-z0-9-~]+).)+([A-Za-z0-9-~\/])+$/;
      if (!reg.test(this.data.linkSrc)) {
        wx.showToast({
          title: '请输入正确的链接！',
          icon: 'none',
          duration: 2000
        })
        return;
      }else{
        this.setData({
          linkContent:true,
          linkShow:false,
        })
      }
    }
  },
  //清除连接
  clearLink(){
    this.setData({
      linkContent: false,
      linkSrc:''
    })
  },
  //获取定位
  locationGet: function () {
    this.setData({
      locationText:'...'
    })
    let vm = this;
    wx.getSetting({
      success: (res) => {
        // res.authSetting['scope.userLocation'] == undefined    表示 初始化进入该页面
        // res.authSetting['scope.userLocation'] == false    表示 非初始化进入该页面,且未授权
        // res.authSetting['scope.userLocation'] == true    表示 地理位置授权
        // 拒绝授权后再次进入重新授权
        if (res.authSetting['scope.userLocation'] != undefined && res.authSetting['scope.userLocation'] != true) {
          // console.log('authSetting:status:拒绝授权后再次进入重新授权', res.authSetting['scope.userLocation'])
          wx.showModal({
            title: '',
            content: '需要获取你的地理位置，请确认授权',
            success: function (res) {
              if (res.cancel) {
                wx.showToast({
                  title: '拒绝授权',
                  icon: 'none'
                })
                setTimeout(() => {
                  wx.navigateBack()
                }, 1500)
              } else if (res.confirm) {
                wx.openSetting({
                  success: function (dataAu) {
                    // console.log('dataAu:success', dataAu)
                    if (dataAu.authSetting["scope.userLocation"] == true) {
                      //再次授权，调用wx.getLocation的API
                      vm.getLocation(dataAu)
                    } else {
                      wx.showToast({
                        title: '授权失败',
                        icon: 'none'
                      })
                      setTimeout(() => {
                        wx.navigateBack()
                      }, 1500)
                    }
                  }
                })
              }
            }
          })
        }
        // 初始化进入，未授权
        else if (res.authSetting['scope.userLocation'] == undefined) {
          // console.log('authSetting:status:初始化进入，未授权', res.authSetting['scope.userLocation'])
          //调用wx.getLocation的API
          vm.getLocation(res)
        }
        // 已授权
        else if (res.authSetting['scope.userLocation']) {
          // console.log('authSetting:status:已授权', res.authSetting['scope.userLocation'])
          //调用wx.getLocation的API
          vm.getLocation(res)
        }
      }
    })
  },
  // 微信获得经纬度
  getLocation: function (userLocation) {
    let vm = this
    wx.getLocation({
      type: "wgs84",
      success: function (res) {
        // console.log('getLocation:success', res)
        var latitude = res.latitude
        var longitude = res.longitude
        vm.getDaiShu(latitude, longitude)
      },
      fail: function (res) {
        // console.log('getLocation:fail', res)
        if (res.errMsg === 'getLocation:fail:auth denied') {
          wx.showToast({
            title: '拒绝授权',
            icon: 'none'
          })
          setTimeout(() => {
            wx.navigateBack()
          }, 1500)
          return
        }
        if (!userLocation || !userLocation.authSetting['scope.userLocation']) {
          vm.getUserLocation()
        } else if (userLocation.authSetting['scope.userLocation']) {
          wx.showModal({
            title: '',
            content: '请在系统设置中打开定位服务',
            showCancel: false,
            success: result => {
              if (result.confirm) {
                wx.navigateBack()
              }
            }
          })
        } else {
          wx.showToast({
            title: '授权失败',
            icon: 'none'
          })
          setTimeout(() => {
            wx.navigateBack()
          }, 1500)
        }
      }
    })
  },
  getDaiShu: function (i, j) {
    // console.log(i, j)
    let me=this;
    let getAddressUrl ='https://apis.map.qq.com/ws/geocoder/v1/?location=' + i + "," + j + "&key=SKJBZ-C5KW5-43HI6-QDES3-57ZSV-KWBEX"
    wx.request({
      url: getAddressUrl,
      success: function (result) {
        console.log(result.data.result.address )
        me.setData({
          locationText: result.data.result.address
        })
      }
    })
  },
  //选择图片
  chooseImg(){
    let me=this;
    wx.chooseImage({
      count: 9,
      sizeType: ['original', 'compressed'],
      sourceType: ['album', 'camera'],
      success(res) {
        // tempFilePath可以作为img标签的src属性显示图片
        // const tempFilePaths = res.tempFilePaths
        const images = me.data.imagesList.concat(res.tempFilePaths);
        me.setData({
          imagesUpload:true,
          imagesList: images.length <= 9 ? images : images.slice(0, 9) 
        })
        console.log(me.data.imagesList)
      }
    })
  },
  clearImg(e){//清理当前上传图片
    let me=this;
    let inde=e.target.dataset.inde;
    let images = me.data.imagesList.splice(inde, 1);
    
    this.setData({
      imagesList: me.data.imagesList
    })
    // console.log(me.data.imagesList)
  },
  // 选择表情包
  chooseEmojis(e){
    console.log(e.target.dataset.index)
    let index = e.target.dataset.index;
    let that = this;
    if(index<10){
      index='0'+index;
    }
    that.editorCtx.insertImage({
      src: 'http://192.168.5.147:5001/emojis/' +index+'.gif',
      width: '20px',
      height: '20px',
    })
  },
  // edior
  // 初始化编辑器
  onEditorReady() {
    let that=this;
    console.log(wx.createSelectorQuery().select('#editors'))
    wx.createSelectorQuery().select('#editors').context(function (res) {
      that.editorCtx = res.context    
      if (wx.getStorageSync("content")) { // 设置~历史值
        that.editorCtx.insertText(wx.getStorageSync("content")) // 注意：插入的是对象
      }

    }).exec();
  },
  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    let that=this
  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {

  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {

  }
})