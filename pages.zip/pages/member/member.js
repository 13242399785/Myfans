// pages/member/member.js
Page({

  /**
   * 页面的初始数据
   */
  data: {
    selected: 0,
    color: "#444",
    selectedColor: "#444",
    activea: 'activea',
    list: [{
      iconClass: 'icon-zhuye mycommunity',
      pagePath: "pages/index/index",
      text: "社区"
    }, {
      iconClass: 'icon-add-fill boxShow',
        pagePath: "pages/post/post",
      text: "发布"
    }, {
      // iconClass: 'icon-guanzhu',
        pagePath: "pages/member/member",
      text: "我的"
    }],
    cardList:[
      {
        title:'我的',list:[
        { icon: 'icon-pinglun', name: '我的评论' },
        { icon: 'icon-dianzan', name: '我的点赞' },
        { icon: 'icon-shoucang', name: '我的收藏' },
        { icon:'icon-guanzhu',name:'我的关注'}
      ]},
      {
        title: '发现', list: [
          { icon: 'icon-jifenshangcheng', name: '积分商城' },
          { icon: 'icon-shoukuan', name: '社区抽奖' },
          { icon: 'icon-shequhuodong', name: '社区活动' },
          { icon: 'icon-yaoqing', name: '邀请好友' },
          { icon: 'icon-caiquan', name: '擂主大奖赛' },
          { icon: 'icon-youhuiquan', name: '商城优惠券' }
        ]
      },
       {
        title: '设置', list: [
          { icon: 'icon-shezhi', name: '基础设置' },
          { icon: 'icon-tousu', name: '投诉' },
        ]
      }
    ] 
  },
  switchTab(e) {
    const data = e.currentTarget.dataset
    const url = '../' + data.path;
    wx.navigateTo({
      url: '../' + url
    })
    this.setData({
      selected: data.index
    })
  },
  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {

  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {

  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {

  }
})