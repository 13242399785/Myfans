//index.js
//获取应用实例
const app = getApp()

Page({
  data: {
    headerImg:'https://cdn.myfans.cc/177363_0_ly4zt3ivsa.jpg',
    userInfos: {
      imgUrl:'https://cdn.myfans.cc/177363_0_me25rmzcy8.jpg?imageView2/1/w/132/h/132',
      name:'  魔法少女和精神小伙的日常'
    },
    userInfo:{},
    currentId:1,
    serchShow:false,
    barrageShow:false,//弹幕
    navList: [{ name: '全部', typeId: 1 }, { name: '活跃', typeId:2}],//nav列表
    hasUserInfo: false,
    canIUse: wx.canIUse('button.open-type.getUserInfo'),
    selected: 0,
    color: "#444",
    selectedColor: "#444",
    activea: 'activea',
    list: [{
      iconClass: 'icon-shuaxin',
      pagePath: "pages/index/index",
      text: "刷新"
    }, {
      iconClass: 'icon-add-fill boxShow',
        pagePath: "pages/post/post",
      text: "发布"
    }, {
      // iconClass: 'icon-guanzhu',
        pagePath: "pages/member/member",
      text: "我的"
    }],
    // swiper
    backgroundList:[
      { img: 'https://cdn.myfans.cc/177363_0_auw9bcycbh.jpg?imageView2/1/w/1200/h/300' },
      { img: 'https://cdn.myfans.cc/177363_0_kd7l30hbyk.jpg?imageView2/1/w/1200/h/300' },
      { img: 'https://cdn.myfans.cc/177363_0_auw9bcycbh.jpg?imageView2/1/w/1200/h/300' },
      { img:'https://cdn.myfans.cc/177363_0_auw9bcycbh.jpg?imageView2/1/w/1200/h/300'},
    ],
    backgroundList1: [
      { img: 'https://cdn.myfans.cc/177363_0_auw9bcycbh.jpg?imageView2/1/w/1200/h/300',title:'晒出圣诞气氛',url:'' },
      { img: 'https://cdn.myfans.cc/177363_0_kd7l30hbyk.jpg?imageView2/1/w/1200/h/300',title:'上班了吗',url:''},
    ],
    allList:[//nav
      { 'name': '全部内容', 'id': 0 },
      { 'name': '精华内容', 'id': 1 },
      { 'name': '晒出圣诞气氛', 'id': 2 },
      { 'name': '梦享商户', 'id': 3 },
      { 'name': '狼人杀组局热线', 'id':4 },
      { 'name': '约个热线', 'id':5 },
      { 'name': '牵狗绳和猫砂铲使用心得', 'id': 6 },
      { 'name': '健身狂魔', 'id': 7 },
      { 'name':'精致生活大爆炸','id':8}
    ],
    // huoyue
    briskList:[
      { name: "BEABALife", logo: "https://cdn.myfans.cc/177363_8243996_rw161hdnlj.jpg?imageView2/1/w/150/h/150", info: '凤凰传奇' },
      { name: "BEABALife", logo: "https://cdn.myfans.cc/0mk4bjmF7uo1529912125.jpg?imageView2/1/w/132/h/132", info: '凤凰传奇' },
      { name: "BEABALife", logo: "https://cdn.myfans.cc/0mk4bjmF7uo1529912125.jpg?imageView2/1/w/132/h/132", info: '凤凰传奇' },
      { name: "BEABALife", logo: "https://cdn.myfans.cc/0mk4bjmF7uo1529912125.jpg?imageView2/1/w/132/h/132", info: '凤凰传奇' },
      { name: "BEABALife", logo: "https://cdn.myfans.cc/0mk4bjmF7uo1529912125.jpg?imageView2/1/w/132/h/132", info: '凤凰传奇' },
      { name: "BEABALife", logo: "https://cdn.myfans.cc/0mk4bjmF7uo1529912125.jpg?imageView2/1/w/132/h/132", info: '凤凰传奇' },
      { name: "BEABALife", logo: "https://cdn.myfans.cc/0mk4bjmF7uo1529912125.jpg?imageView2/1/w/132/h/132", info: '凤凰传奇' },
      { name: "BEABALife", logo: "https://cdn.myfans.cc/0mk4bjmF7uo1529912125.jpg?imageView2/1/w/132/h/132", info: '凤凰传奇' },
      { name: "BEABALife", logo: "https://cdn.myfans.cc/0mk4bjmF7uo1529912125.jpg?imageView2/1/w/132/h/132", info: '凤凰传奇' },
      { name: "BEABALife", logo: "https://cdn.myfans.cc/0mk4bjmF7uo1529912125.jpg?imageView2/1/w/132/h/132",info:'凤凰传奇'},
    ],
    showIcon:false,
    showActionsheet: false,
    groups: [
      { text: '收藏', value: 1 },
      { text: '生成图片', value: 2 },
      { text: '举报', value: 3 }
    ],
    dataList:[
      { name: '我是一个整体', logo: 'https://cdn.myfans.cc/177363_8243996_rw161hdnlj.jpg?imageView2/1/w/150/h/150', id: 0, time: '时间', lable: ['标签'], title: '这是标题', topic: '#话题标签#', content: '内容标签', type: 'weitie', img: [], zang: '6', review: '12', video: 'https://cdn.myfans.cc/177363mURn3D1576742312.mp4', recommend:'stick'},
      { name: '我是一个整体', logo: 'https://cdn.myfans.cc/177363_8243996_rw161hdnlj.jpg?imageView2/1/w/150/h/150', id: 1, time: '时间', lable: ['标签'], title: '这是标题', topic: '话题标签', content: '内容标签', type: 'weitie', img: ['https://cdn.myfans.cc/0mk4bjmF7uo1529912125.jpg?imageView2/1/w/132/h/132', 'https://cdn.myfans.cc/0mk4bjmF7uo1529912125.jpg?imageView2/1/w/132/h/132'], zang: '0', review: '12' },
      { name: '我是一个整体', logo: 'https://cdn.myfans.cc/177363_8243996_rw161hdnlj.jpg?imageView2/1/w/150/h/150', id: 2, time: '时间', lable: ['标签'], title: '这是标题', topic: '话题标签', content: '内容标签', type: 'weitie', img: ['https://cdn.myfans.cc/0mk4bjmF7uo1529912125.jpg?imageView2/1/w/132/h/132'], zang: '2', review: '12' },
      { name: '我是一个整体', logo: 'https://cdn.myfans.cc/177363_8243996_rw161hdnlj.jpg?imageView2/1/w/150/h/150', id: 3, time: '时间', lable: ['标签'], title: '这是标题', topic: '话题标签', content: '内容标签', type: 'weitie', img: ['https://cdn.myfans.cc/0mk4bjmF7uo1529912125.jpg?imageView2/1/w/132/h/132', 'https://cdn.myfans.cc/0mk4bjmF7uo1529912125.jpg?imageView2/1/w/132/h/132'], zang: '6', review: '12',music:{
        name: '歌手名称', title: '歌名', src:'https://nc01-sycdn.kuwo.cn/d99e80bee42c81eeccbbcb6993833950/5e02fb8d/resource/n2/95/83/2798960634.mp3'
      } },
      { name: '我是一个整体', logo: 'https://cdn.myfans.cc/177363_8243996_rw161hdnlj.jpg?imageView2/1/w/150/h/150', id: 4, time: '时间', lable: ['标签'], title: '这是标题', topic: '话题标签', content: '内容标签', type: 'weitie', img: ['https://cdn.myfans.cc/0mk4bjmF7uo1529912125.jpg?imageView2/1/w/132/h/132', 'https://cdn.myfans.cc/0mk4bjmF7uo1529912125.jpg?imageView2/1/w/132/h/132', 'https://cdn.myfans.cc/0mk4bjmF7uo1529912125.jpg?imageView2/1/w/132/h/132', 'https://cdn.myfans.cc/0mk4bjmF7uo1529912125.jpg?imageView2/1/w/132/h/132'], zang: '6', review: '0' },
    ],
    commentShow:false,//评论框
  },
  //事件处理函数
  bindViewTap: function() {
    wx.navigateTo({
      url: '../logs/logs'
    })
  },
  onReady: function (e) {
    // 使用 wx.createAudioContext 获取 audio 上下文 context
    this.audioCtx = wx.createAudioContext('myAudio')
  },
  musicControl(){
    console.log(111)
    console.log(this.audioCtx)
    this.audioCtx.play()
  },
  onLoad: function () {
    if (app.globalData.userInfo) {
      this.setData({
        userInfo: app.globalData.userInfo,
        hasUserInfo: true
      })
    } else if (this.data.canIUse){
      // 由于 getUserInfo 是网络请求，可能会在 Page.onLoad 之后才返回
      // 所以此处加入 callback 以防止这种情况
      app.userInfoReadyCallback = res => {
        this.setData({
          userInfo: res.userInfo,
          hasUserInfo: true
        })
      }
    } else {
      // 在没有 open-type=getUserInfo 版本的兼容处理
      wx.getUserInfo({
        success: res => {
          app.globalData.userInfo = res.userInfo
          this.setData({
            userInfo: res.userInfo,
            hasUserInfo: true
          })
        }
      })
    }
  },
  getUserInfo: function(e) {
    console.log(e)
    app.globalData.userInfo = e.detail.userInfo
    this.setData({
      userInfo: e.detail.userInfo,
      hasUserInfo: true
    })
  },
  switchTab(e) {
    const data = e.currentTarget.dataset
    const url = '../' + data.path;
    wx.navigateTo({
      url: '../' + url
    })
    this.setData({
      selected: data.index
    })
  },
  //点击导航事件
  handleTap: function (e) {
    let id = e.currentTarget.id;
    if (id) {
      this.setData({
        currentId: id
      })
    }
  },
  //点击显示更多标签
  controlNavIcon() {
    let me=this;
    if (this.data.showIcon==false){
      this.setData({
        showIcon: true
      }) 
    }else{
      this.setData({
        showIcon: false
      })
    }
  },
  closeMoke: function () {
    this.setData({
      showActionsheet: false
    })
  },
  shwoMoke(e){
    console.log(e)
    if(e){
      this.setData({
        showActionsheet: true
      })
    }
  },
  //选择事件
  btnClick(e) {
    console.log(e)
    this.closeMoke()
  },
  //搜索
  souShow(){
    this.setData({
      serchShow: true
    })
  },
  cancelSou(){
    this.setData({
      serchShow: false
    })
  },
  //弹幕
  barrageC(){
    if (this.data.barrageShow==true){
      this.setData({
        barrageShow: false
      })
    }else{
      this.setData({
        barrageShow: true
      })
    }
  },
  //评论框
  commentC(){
    if (this.data.commentShow == true) {
      this.setData({
        commentShow: false
      })
    } else {
      this.setData({
        commentShow: true
      })
    }
  }
})
